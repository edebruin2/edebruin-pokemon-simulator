package Moves;

public interface Moves {
    int powerValue = 0;
    String type = null;
    String attackType = null;

    int getPowerValue();

    String getType();

    String getAttackType();
}

