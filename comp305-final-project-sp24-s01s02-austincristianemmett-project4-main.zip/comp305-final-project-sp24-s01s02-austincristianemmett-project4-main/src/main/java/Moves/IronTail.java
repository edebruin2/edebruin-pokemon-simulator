package Moves;

public class IronTail implements Moves{
    int powerValue = 100;
    String type = "Steel";
    String attackType = "Attack";

    @Override
    public int getPowerValue() {
        return powerValue;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public String getAttackType() {
        return attackType;
    }
}
