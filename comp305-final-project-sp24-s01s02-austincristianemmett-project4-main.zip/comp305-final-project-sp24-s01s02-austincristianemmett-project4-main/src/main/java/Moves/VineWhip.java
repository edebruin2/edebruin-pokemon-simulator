package Moves;

public class VineWhip implements Moves{
    int powerValue = 45;
    String type = "Grass";
    String attackType = "Attack";

    @Override
    public int getPowerValue() {
        return powerValue;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public String getAttackType() {
        return attackType;
    }
}
